//prototypes

float c_to_f(float);
float c_to_k(float);
