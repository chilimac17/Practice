//function definition for cube()

int cube(int n) {
    return n*n*n;
}



