//This program will return the cube value
//of an input value

#include "cube.h"
#define NUMBER 4

int main(void) {
    return cube(NUMBER);
}

