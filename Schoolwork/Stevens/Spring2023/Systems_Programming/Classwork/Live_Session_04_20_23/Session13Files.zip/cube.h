//prototype for function cube()

int cube(int);

