#include<stdio.h>
#include<unistd.h>

int main() {

   while (1) {
   printf("hello\n");
   sleep(1);
   }
}

